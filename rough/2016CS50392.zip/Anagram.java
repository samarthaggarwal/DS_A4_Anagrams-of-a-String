import java.util.*;
import java.io.*;

public class Anagram{
	static final int t_size=10000;
		// hash table
	static Vector<String>[] table; 

	static boolean match(String s1, String s2){
		int[] arr1 = new int[37];
		int[] arr2 = new int[37];
		int l = s1.length();
		for(int i=0;i<l;i++){
			if( s1.charAt(i)=='0' ) arr1[0]++;
			else if( s1.charAt(i)=='1' ) arr1[1]++;
			else if( s1.charAt(i)=='2' ) arr1[2]++;
			else if( s1.charAt(i)=='3' ) arr1[3]++;
			else if( s1.charAt(i)=='4' ) arr1[4]++;
			else if( s1.charAt(i)=='5' ) arr1[5]++;
			else if( s1.charAt(i)=='6' ) arr1[6]++;
			else if( s1.charAt(i)=='7' ) arr1[7]++;
			else if( s1.charAt(i)=='8' ) arr1[8]++;
			else if( s1.charAt(i)=='9' ) arr1[9]++;
			else if( s1.charAt(i)=='\'' ) arr1[10]++;
			else if(s1.charAt(i)>='a' && s1.charAt(i)<='z') arr1[s1.charAt(i)-'a'+11] ++;
		}
		l = s2.length();
		for(int i=0;i<l;i++){
			if( s2.charAt(i)=='0' ) arr2[0]++;
			else if( s2.charAt(i)=='1' ) arr2[1]++;
			else if( s2.charAt(i)=='2' ) arr2[2]++;
			else if( s2.charAt(i)=='3' ) arr2[3]++;
			else if( s2.charAt(i)=='4' ) arr2[4]++;
			else if( s2.charAt(i)=='5' ) arr2[5]++;
			else if( s2.charAt(i)=='6' ) arr2[6]++;
			else if( s2.charAt(i)=='7' ) arr2[7]++;
			else if( s2.charAt(i)=='8' ) arr2[8]++;
			else if( s2.charAt(i)=='9' ) arr2[9]++;
			else if( s2.charAt(i)=='\'' ) arr2[10]++;
			else if(s2.charAt(i)>='a' && s2.charAt(i)<='z') arr2[s2.charAt(i)-'a'+11] ++;
		}
		for(int i=0;i<37;i++){
			if(arr1[i]!=arr2[i]) return false;
		}
		return true;

	}

	static int hash_arr(int[] arr){
		int h_val=0;
		for(int i=36;i>=0;i--){
			h_val = ( arr[i] + h_val*13 ) % t_size ;
		}
		return h_val;
	}

	static int hash( String tmp ){
		int h_val=0;
		int l = tmp.length();
		if(l>12) return -1;
		int[] arr = new int[37];
		for(int i=0;i<l;i++){
			if( tmp.charAt(i)=='0' ) arr[0]++;
			else if( tmp.charAt(i)=='1' ) arr[1]++;
			else if( tmp.charAt(i)=='2' ) arr[2]++;
			else if( tmp.charAt(i)=='3' ) arr[3]++;
			else if( tmp.charAt(i)=='4' ) arr[4]++;
			else if( tmp.charAt(i)=='5' ) arr[5]++;
			else if( tmp.charAt(i)=='6' ) arr[6]++;
			else if( tmp.charAt(i)=='7' ) arr[7]++;
			else if( tmp.charAt(i)=='8' ) arr[8]++;
			else if( tmp.charAt(i)=='9' ) arr[9]++;
			else if( tmp.charAt(i)=='\'' ) arr[10]++;
			else if(tmp.charAt(i)>='a' && tmp.charAt(i)<='z') arr[tmp.charAt(i)-'a'+11] ++;
			else return -1;
		}
		for(int i=36;i>=0;i--){
			h_val = ( arr[i] + h_val*13 ) % t_size ;
		}
		return(h_val);
	}

	static void search(String str){
		// length <3 or >12
			Vector<String> vv =new Vector<String>();

		int i = hash(str);
		if(str.length()<=12 && str.length()>=3 && i!=-1){	
//			if(str.length()>12) return;
			int n = table[i].size();
			for(int j=0;j<n;j++){
				if(match(table[i].get(j),str)==true )
					//System.out.println(table[i].get(j));
					vv.add(table[i].get(j));
			}

			split2(str,vv);
			split3(str,vv);

			 Collections.sort(vv);
		 //System.out.println(vv.size());
		}
		 //vv.add("-1");
		 BufferedWriter log = new BufferedWriter(new OutputStreamWriter(System.out));
		 try{
			 for(int g=0;g<vv.size();g++){
			 	log.write(vv.get(g)+"\n");
			 	//System.out.println(vv.get(g));
			}
			log.write("-1"+"\n");
			log.flush();
	}
		catch(IOException e){}

	}
	


	static Vector<String> find(String str){
		Vector<String> v = new Vector<String>();
		int i = hash(str);
		int n = table[i].size();
		for(int j=0;j<n;j++){
				if(match(table[i].get(j),str)==true) v.add(table[i].get(j));
		}
		return v;
	}

	static String minus(String s1, String s2){ //  returns s1-s2
		int[] arr= new int[37];
		StringBuffer s = new StringBuffer("");
		int l = s1.length();
		for(int i=0;i<l;i++){
			if( s1.charAt(i)=='0' ) arr[0]++;
			else if( s1.charAt(i)=='1' ) arr[1]++;
			else if( s1.charAt(i)=='2' ) arr[2]++;
			else if( s1.charAt(i)=='3' ) arr[3]++;
			else if( s1.charAt(i)=='4' ) arr[4]++;
			else if( s1.charAt(i)=='5' ) arr[5]++;
			else if( s1.charAt(i)=='6' ) arr[6]++;
			else if( s1.charAt(i)=='7' ) arr[7]++;
			else if( s1.charAt(i)=='8' ) arr[8]++;
			else if( s1.charAt(i)=='9' ) arr[9]++;
			else if( s1.charAt(i)=='\'' ) arr[10]++;
			else if(s1.charAt(i)>='a' && s1.charAt(i)<='z') arr[s1.charAt(i)-'a'+11] ++;
		}
		l=s2.length();
		for(int i=0;i<l;i++){
			if( s2.charAt(i)=='0' ) arr[0]--;
			else if( s2.charAt(i)=='1' ) arr[1]--;
			else if( s2.charAt(i)=='2' ) arr[2]--;
			else if( s2.charAt(i)=='3' ) arr[3]--;
			else if( s2.charAt(i)=='4' ) arr[4]--;
			else if( s2.charAt(i)=='5' ) arr[5]--;
			else if( s2.charAt(i)=='6' ) arr[6]--;
			else if( s2.charAt(i)=='7' ) arr[7]--;
			else if( s2.charAt(i)=='8' ) arr[8]--;
			else if( s2.charAt(i)=='9' ) arr[9]--;
			else if( s2.charAt(i)=='\'' ) arr[10]--;
			else if(s2.charAt(i)>='a' && s2.charAt(i)<='z') arr[s2.charAt(i)-'a'+11] --;
		}
		for(int i=0;i<37;i++){
			for(int j=0;j<arr[i];j++){
				if(i==0) s.append("0");
				else if(i==1) s.append("1");
				else if(i==2) s.append("2");
				else if(i==3) s.append("3");
				else if(i==4) s.append("4");
				else if(i==5) s.append("5");
				else if(i==6) s.append("6");
				else if(i==7) s.append("7");
				else if(i==8) s.append("8");
				else if(i==9) s.append("9");
				else if(i==10) s.append("\'");
				else if(i==11) s.append("a");
				else if(i==12) s.append("b");
				else if(i==13) s.append("c");
				else if(i==14) s.append("d");
				else if(i==15) s.append("e");
				else if(i==16) s.append("f");
				else if(i==17) s.append("g");
				else if(i==18) s.append("h");
				else if(i==19) s.append("i");
				else if(i==20) s.append("j");
				else if(i==21) s.append("k");
				else if(i==22) s.append("l");
				else if(i==23) s.append("m");
				else if(i==24) s.append("n");
				else if(i==25) s.append("o");
				else if(i==26) s.append("p");
				else if(i==27) s.append("q");
				else if(i==28) s.append("r");
				else if(i==29) s.append("s");
				else if(i==30) s.append("t");
				else if(i==31) s.append("u");
				else if(i==32) s.append("v");
				else if(i==33) s.append("w");
				else if(i==34) s.append("x");
				else if(i==35) s.append("y");
				else if(i==36) s.append("z");				
			}
		}
		return s.toString();
	}

	static void split2(String str, Vector<String> vec){
		int l = str.length();
		Vector<String> part = new Vector<String>();
		if(l==6){
			getCombination(str,l,3,part);
			int x = part.size();
			Vector<String> v1 = part;
			for(int i=0;i<x;i++){
				Vector<String> h1 = find(v1.get(i));
				int n1=h1.size();
				if(n1!=0){
					 Vector<String> h2 = find(minus(str,v1.get(i)));
					 int n2 = h2.size(); 
					 if(n2!=0){
					 	for(int m=0;m<n1;m++){
					 		for(int n=0;n<n2;n++){
					 			vec.add(h1.get(m)+" "+h2.get(n));
					 			//System.out.println(h1.get(m)+" "+h2.get(n));
					 		}
					 	}
					 }
				}
			}
			//perms 
			//if both exist add in vector
		}
		else if(l==7){
			getCombination(str,l,3,part);
			int x = part.size();
			for(int i=0;i<x;i++){
				Vector<String> h1 = find(part.get(i));
				int n1=h1.size();
				if(n1!=0){
					 Vector<String> h2 = find(minus(str,part.get(i)));
					 int n2 = h2.size(); 
					 if(n2!=0){
					 	for(int m=0;m<n1;m++){
					 		for(int n=0;n<n2;n++){
					 			vec.add(h1.get(m)+" "+h2.get(n));
					 			vec.add(h2.get(n)+" "+h1.get(m));
					 		}
					 	}		
					 }
				}			
			}
		}
		else if(l==8){
			getCombination(str,l,3,part);
			int x = part.size();
			Vector<String> h1,h2;
			int n1,n2;
			// 3+5
			for(int i=0;i<x;i++){
				h1 = find(part.get(i));
				n1=h1.size();
				if(n1!=0){
					 h2 = find(minus(str,part.get(i)));
					 n2 = h2.size(); 
					 if(n2!=0){
					 	for(int m=0;m<n1;m++){
					 		for(int n=0;n<n2;n++){
					 			vec.add(h1.get(m)+" "+h2.get(n));
					 			vec.add(h2.get(n)+" "+h1.get(m));
					 		}
					 	}		
					 }
				}			
			}
			
			// 4+4
			Vector<String> part2 = new Vector<String>();
			getCombination(str,l,4,part2);
			x=part2.size();
			for(int i=0;i<x;i++){
				h1 = find(part2.get(i));
				n1=h1.size();
				if(n1!=0){
					 h2 = find(minus(str,part2.get(i)));
					 n2 = h2.size(); 
					 if(n2!=0){
					 	for(int m=0;m<n1;m++){
					 		for(int n=0;n<n2;n++){
					 			vec.add(h1.get(m)+" "+h2.get(n));
					 		}
					 	}		
					 }
				}			
			}

		}

		else if(l==9){
			// 3+6
			getCombination(str,l,3,part);
			int x = part.size();
			Vector<String> h1,h2;
			int n1,n2;
			for(int i=0;i<x;i++){
				h1 = find(part.get(i));
				n1=h1.size();
				if(n1!=0){
					 h2 = find(minus(str,part.get(i)));
					 n2 = h2.size(); 
					 if(n2!=0){
					 	for(int m=0;m<n1;m++){
					 		for(int n=0;n<n2;n++){
					 			vec.add(h1.get(m)+" "+h2.get(n));
					 			vec.add(h2.get(n)+" "+h1.get(m));
					 		}
					 	}		
					 }
				}			
			}

			// 4+5
			Vector<String> part2 = new Vector<String>();
			getCombination(str,l,4,part2);
			x=part2.size();
			for(int i=0;i<x;i++){
				h1 = find(part2.get(i));
				n1=h1.size();
				if(n1!=0){
					 h2 = find(minus(str,part2.get(i)));
					 n2 = h2.size(); 
					 if(n2!=0){
					 	for(int m=0;m<n1;m++){
					 		for(int n=0;n<n2;n++){
					 			vec.add(h1.get(m)+" "+h2.get(n));
					 			vec.add(h2.get(n)+" "+h1.get(m));
					 		}
					 	}		
					 }
				}			
			}
		}
		else if(l==10){
			// 3+7
			getCombination(str,l,3,part);
			int x = part.size();
			Vector<String> h1,h2;
			int n1,n2;
			for(int i=0;i<x;i++){
				h1 = find(part.get(i));
				n1=h1.size();
				if(n1!=0){
					 h2 = find(minus(str,part.get(i)));
					 n2 = h2.size(); 
					 if(n2!=0){
					 	for(int m=0;m<n1;m++){
					 		for(int n=0;n<n2;n++){
					 			vec.add(h1.get(m)+" "+h2.get(n));
					 			vec.add(h2.get(n)+" "+h1.get(m));
					 		}
					 	}		
					 }
				}			
			}
			// 4+6
			Vector<String> part2 = new Vector<String>();
			getCombination(str,l,4,part2);
			x=part2.size();
			for(int i=0;i<x;i++){
				h1 = find(part2.get(i));
				n1=h1.size();
				if(n1!=0){
					 h2 = find(minus(str,part2.get(i)));
					 n2 = h2.size(); 
					 if(n2!=0){
					 	for(int m=0;m<n1;m++){
					 		for(int n=0;n<n2;n++){
					 			vec.add(h1.get(m)+" "+h2.get(n));
					 			vec.add(h2.get(n)+" "+h1.get(m));
					 		}
					 	}		
					 }
				}			
			}
			// 5+5
			Vector<String> part3 = new Vector<String>();
			getCombination(str,l,5,part3);
			x=part3.size();
			for(int i=0;i<x;i++){
				h1 = find(part3.get(i));
				n1=h1.size();
				if(n1!=0){
					 h2 = find(minus(str,part3.get(i)));
					 n2 = h2.size(); 
					 if(n2!=0){
					 	for(int m=0;m<n1;m++){
					 		for(int n=0;n<n2;n++){
					 			vec.add(h1.get(m)+" "+h2.get(n));
					 		}
					 	}		
					 }
				}			
			}

		}
		else if(l==11){
			// 3+8
			getCombination(str,l,3,part);
			int x = part.size();
			Vector<String> h1,h2;
			int n1,n2;
			for(int i=0;i<x;i++){
				h1 = find(part.get(i));
				n1=h1.size();
				if(n1!=0){
					 h2 = find(minus(str,part.get(i)));
					 n2 = h2.size(); 
					 if(n2!=0){
					 	for(int m=0;m<n1;m++){
					 		for(int n=0;n<n2;n++){
					 			vec.add(h1.get(m)+" "+h2.get(n));
					 			vec.add(h2.get(n)+" "+h1.get(m));
					 		}
					 	}		
					 }
				}			
			}
			// 4+7
			Vector<String> part2 = new Vector<String>();
			getCombination(str,l,4,part2);
			x=part2.size();
			for(int i=0;i<x;i++){
				h1 = find(part2.get(i));
				n1=h1.size();
				if(n1!=0){
					 h2 = find(minus(str,part2.get(i)));
					 n2 = h2.size(); 
					 if(n2!=0){
					 	for(int m=0;m<n1;m++){
					 		for(int n=0;n<n2;n++){
					 			vec.add(h1.get(m)+" "+h2.get(n));
					 			vec.add(h2.get(n)+" "+h1.get(m));
					 		}
					 	}		
					 }
				}			
			}
			// 5+6
			Vector<String> part3 = new Vector<String>();
			getCombination(str,l,5,part3);
			x=part3.size();
			for(int i=0;i<x;i++){
				h1 = find(part3.get(i));
				n1=h1.size();
				if(n1!=0){
					 h2 = find(minus(str,part3.get(i)));
					 n2 = h2.size(); 
					 if(n2!=0){
					 	for(int m=0;m<n1;m++){
					 		for(int n=0;n<n2;n++){
					 			vec.add(h1.get(m)+" "+h2.get(n));
					 			vec.add(h2.get(n)+" "+h1.get(m));
					 		}
					 	}		
					 }
				}			
			}
		}
		else if(l==12){
			// 3+9
			getCombination(str,l,3,part);
			int x = part.size();
			Vector<String> h1,h2;
			int n1,n2;
			for(int i=0;i<x;i++){
				h1 = find(part.get(i));
				n1=h1.size();
				if(n1!=0){
					 h2 = find(minus(str,part.get(i)));
					 n2 = h2.size(); 
					 if(n2!=0){
					 	for(int m=0;m<n1;m++){
					 		for(int n=0;n<n2;n++){
					 			vec.add(h1.get(m)+" "+h2.get(n));
					 			vec.add(h2.get(n)+" "+h1.get(m));
					 		}
					 	}		
					 }
				}			
			}
			// 4+8
			Vector<String> part2 = new Vector<String>();
			getCombination(str,l,4,part2);
			x=part2.size();
			for(int i=0;i<x;i++){
				h1 = find(part2.get(i));
				n1=h1.size();
				if(n1!=0){
					 h2 = find(minus(str,part2.get(i)));
					 n2 = h2.size(); 
					 if(n2!=0){
					 	for(int m=0;m<n1;m++){
					 		for(int n=0;n<n2;n++){
					 			vec.add(h1.get(m)+" "+h2.get(n));
					 			vec.add(h2.get(n)+" "+h1.get(m));
					 		}
					 	}		
					 }
				}			
			}
			// 5+7
			Vector<String> part3 = new Vector<String>();
			getCombination(str,l,5,part3);
			x=part3.size();
			for(int i=0;i<x;i++){
				h1 = find(part3.get(i));
				n1=h1.size();
				if(n1!=0){
					 h2 = find(minus(str,part3.get(i)));
					 n2 = h2.size(); 
					 if(n2!=0){
					 	for(int m=0;m<n1;m++){
					 		for(int n=0;n<n2;n++){
					 			vec.add(h1.get(m)+" "+h2.get(n));
					 			vec.add(h2.get(n)+" "+h1.get(m));
					 		}
					 	}		
					 }
				}			
			}
			// 6+6
			Vector<String> part4 = new Vector<String>();
			getCombination(str,l,6,part4);
			x=part4.size();
			for(int i=0;i<x;i++){
				h1 = find(part4.get(i));
				n1=h1.size();
				if(n1!=0){
					 h2 = find(minus(str,part4.get(i)));
					 n2 = h2.size(); 
					 if(n2!=0){
					 	for(int m=0;m<n1;m++){
					 		for(int n=0;n<n2;n++){
					 			vec.add(h1.get(m)+" "+h2.get(n));
					 			//vec.add(h2.get(n)+" "+h2.get(m));
					 		}
					 	}		
					 }
				}			
			}
		}
	}

	static void split2_44(String str,Vector<String> vec){
		int l = str.length();
		Vector<String> part = new Vector<String>();
		getCombination(str,l,3,part);
		int x = part.size();
		Vector<String> h1,h2;
		int n1,n2;
		Vector<String> part2 = new Vector<String>();
			getCombination(str,l,4,part2);
			x=part2.size();
			for(int i=0;i<x;i++){
				h1 = find(part2.get(i));
				n1=h1.size();
				if(n1!=0){
					 h2 = find(minus(str,part2.get(i)));
					 n2 = h2.size(); 
					 if(n2!=0){
					 	for(int m=0;m<n1;m++){
					 		for(int n=0;n<n2;n++){
					 			vec.add(h1.get(m)+" "+h2.get(n));
					 		}
					 	}		
					 }
				}			
			}
	}

	static void split3(String str, Vector<String> vec){
		int l = str.length();
		Vector<String> part = new Vector<String>();
		Vector<String> h1,h2;
		int n1,n2;
		String s1,s2,s3;
		if(l==9){
			// 3+3+3
			getCombination(str,l,3,part);
			int x = part.size();
			Vector<String> vvv = new Vector<String>();
			for(int i=0;i<x;i++){
				vvv=new Vector<String>();
				s1=part.get(i);
				//System.out.println("s1 is "+s1);
				h1 = find(s1);
				n1=h1.size();
				if(n1!=0){ 
					s2=minus(str,s1);
					//System.out.println(str +" - " +s1 +" is "+s2);
					split2(s2,vvv);
					int y=vvv.size();
					for(int h=0;h<n1;h++){
						for(int j=0;j<y;j++){
							vec.add(h1.get(h)+" "+vvv.get(j));
						}
					}
				}
			}
		}
		else if(l==10){
			// 3+3+4
			getCombination(str,l,4,part);
			int x = part.size();
			Vector<String> vvv = new Vector<String>();
			String str1,str2,str3;
			int a;
			for(int i=0;i<x;i++){
				vvv=new Vector<String>();
				s1=part.get(i);
								//System.out.println("s1 is "+s1);

				h1=find(s1);
				n1=h1.size();
				if(n1!=0){
					s2=minus(str,s1);
					//System.out.println(str +" - " +s1 +" is "+s2);
					//System.out.println("vvv is "+vvv);
					split2(s2,vvv);
					//System.out.println("vvv is "+vvv);
					int y=vvv.size();
					for(int h=0;h<n1;h++){
						for(int j=0;j<y;j++){
							str1=h1.get(h);
							str2=vvv.get(j);
							vec.add(str1+" "+str2); // 4 3 3
							vec.add(str2+" "+str1); // 3 3 4
							a=str2.indexOf(' ');
							str3=str2.substring(a+1);
							str2=str2.substring(0,a);
							vec.add(str2+" "+str1+" "+str3); // 3 4 3
						}
					}
				}
			}			
		}
		else if(l==11){
			// 3+3+5
			getCombination(str,l,5,part);
			int x = part.size();
			Vector<String> vvv = new Vector<String>();
			String str1,str2,str3;
			int a;
			for(int i=0;i<x;i++){
				vvv=new Vector<String>();
				s1=part.get(i);
				h1=find(s1);
				n1=h1.size();
				if(n1!=0){
					s2=minus(str,s1);
					split2(s2,vvv);
					int y=vvv.size();
					for(int h=0;h<n1;h++){
						for(int j=0;j<y;j++){
							str1=h1.get(h);
							str2=vvv.get(j);
							vec.add(str1+" "+str2); // 5 3 3
							vec.add(str2+" "+str1); // 3 3 5
							a=str2.indexOf(' ');
							str3=str2.substring(a+1);
							str2=str2.substring(0,a);
							vec.add(str2+" "+str1+" "+str3); // 3 5 3
						}
					}
				}
			}
			
			// 3+4+4
			Vector<String> part2 = new Vector<String>();
			Vector<String> part3 = new Vector<String>();
			Vector<String> h3 = new Vector<String>();
			Vector<String> vn = new Vector<String>();
			int n3;
			getCombination(str,l,3,part2);    
			x = part2.size();
			for(int i=0;i<x;i++){
				vn=new Vector<String>();
				s1=part2.get(i);
				h1=find(s1);
				n1=h1.size();
				if(n1!=0){
					s2=minus(str,s1);
					split2_44(s2,vn);
					int y=vn.size();
					for(int h=0;h<n1;h++){
						for(int j=0;j<y;j++){
							str1=h1.get(h);
							str2=vn.get(j);
							vec.add(str1+" "+str2); // 3 4 4
							vec.add(str2+" "+str1); // 4 4 3
							a=str2.indexOf(' ');
							str3=str2.substring(a+1);
							str2=str2.substring(0,a);
							vec.add(str2+" "+str1+" "+str3); // 4 3 4
						}
					}
				}
			}

		}
		else if(l==12){
			// 3+3+6
			getCombination(str,l,6,part);
			int x = part.size();
			Vector<String> vvv = new Vector<String>();
			String str1,str2,str3;
			int a;
			for(int i=0;i<x;i++){
				vvv=new Vector<String>();
				s1=part.get(i);
				h1=find(s1);
				n1=h1.size();
				if(n1!=0){
					s2=minus(str,s1);
					split2(s2,vvv);
					int y=vvv.size();
					for(int h=0;h<n1;h++){
						for(int j=0;j<y;j++){
							str1=h1.get(h);
							str2=vvv.get(j);
							vec.add(str1+" "+str2); // 5 3 3
							vec.add(str2+" "+str1); // 3 3 5
							a=str2.indexOf(' ');
							str3=str2.substring(a+1);
							str2=str2.substring(0,a);
							vec.add(str2+" "+str1+" "+str3); // 3 5 3
						}
					}
				}
			}
			// 3+4+5
			Vector<String> part2 = new Vector<String>();
			Vector<String> part3 = new Vector<String>();
			getCombination(str,l,3,part2);	
			x=part2.size();
			int n3;
			Vector<String> h3;
			for(int i=0;i<x;i++){
				s1=part2.get(i);
				h1=find(s1);
				n1=h1.size();
				if(n1!=0){
					part3 = new Vector<String>();
					getCombination(minus(str,s1),minus(str,s1).length(),4,part3);
					int y=part3.size();
					for(int j=0;j<y;j++){
						s2=part3.get(j);
						h2=find(s2);
						n2=h2.size();
						if(n2!=0){
							s3=minus(minus(str,s1),s2);
							h3=find(s3);
							n3=h3.size();
							if(n3!=0){
								for(int aa=0;aa<n1;aa++){
									for(int bb=0;bb<n2;bb++){
										for(int cc=0;cc<n3;cc++){
											s1=h1.get(aa);
											s2=h2.get(bb);
											s3=h3.get(cc);
											vec.add(s1+" "+s2+" "+s3);
											vec.add(s1+" "+s3+" "+s2);
											vec.add(s2+" "+s1+" "+s3);
											vec.add(s2+" "+s3+" "+s1);
											vec.add(s3+" "+s1+" "+s2);
											vec.add(s3+" "+s2+" "+s1);
										}
									}
								}
							}
						}
					}

				}
			}	
			//4+4+4
			part= new Vector<String>();
			getCombination(str,l,4,part);
			x = part.size();
			vvv = new Vector<String>();
			for(int i=0;i<x;i++){
				vvv=new Vector<String>();
				s1=part.get(i);
				//System.out.println("s1 is "+s1);
				h1 = find(s1);
				n1=h1.size();
				if(n1!=0){ 
					s2=minus(str,s1);
					//System.out.println(str +" - " +s1 +" is "+s2);
					split2_44(s2,vvv);
					int y=vvv.size();
					for(int h=0;h<n1;h++){
						for(int j=0;j<y;j++){
							vec.add(h1.get(h)+" "+vvv.get(j));
						}
					}
				}
			}
		
		}
	}


	static String msort(String str,int start){				
		StringBuffer mm= new StringBuffer("");
		mm.append(str.substring(0,start));
		String sm=str.substring(start);	
		char[] arr = sm.toCharArray();
		Arrays.sort(arr);
		sm=(new String(arr));
		mm.append(sm);
		return (mm.toString());
	}


	public static void getCombination(String arr, int n, int r, Vector<String> comb){
		char[] data = new char[r];
		arr = msort(arr,0);
		combinationUtil(arr, data, 0, n-1, 0, r,comb);
		Collections.sort(comb);
		for(int y=1;y<comb.size();y++){
			if(comb.get(y).equals(comb.get(y-1))) {comb.remove(y);y--;}
		}
    }
    public static void combinationUtil(String arr, char data[], int start, int end,int index, int r, Vector<String> comb){
    	if (index == r){
    		String sak = "";
        	for (int j=0; j<r; j++){
        		sak = sak + data[j];
        	}
            comb.add(sak);
        return;
    	}
    	int i;
    	int min;
    	if(end <= end+1-r+index){
        	min = end;
    	}
    	else{
        	min = end+1-r+index;
    	}
    	for (i=start; i<=min; i++)
    	{
	        	data[index] = arr.charAt(i);
	        	combinationUtil(arr, data, i+1, end, index+1, r,comb);
    	}
    }



	public static void main( String[] args ){
		// long time=System.currentTimeMillis();
		try{
			table =  new Vector[t_size];
			for(int i=0;i<t_size;i++){
				table[i]=new Vector<String>();  //
			}
			BufferedReader s = new BufferedReader(new FileReader(args[0]));
			//Scanner s = new Scanner(new File("vocabulary.txt") );
			int n = Integer.parseInt(s.readLine());
			//int n = s.nextInt();
			//s.nextLine();
			String tmp;
			for(int i=0;i<n;i++){
				tmp = s.readLine();
				//tmp = s.nextLine();
				if(hash(tmp)==-1) continue;
				table[hash(tmp)].add(tmp);
			}
			s = new BufferedReader(new FileReader(args[1]));
			//s = new Scanner(new File("vocabulary.txt"));
			n = Integer.parseInt(s.readLine());
			// n = s.nextInt();
			// s.nextLine();
			for(int i=0;i<n;i++){
				search(s.readLine());
				//search(s.nextLine());
			}
		}
		catch(IOException e){}

		// long time2=System.currentTimeMillis() - time;
		// System.out.println("time " + time2 + "ms");

	}


}